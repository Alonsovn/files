import React, { useState } from "react";
import CustomTable from "../../components/Table/Table";
import { Button, Upload, message, notification, Modal, Row, Col, Typography, Select } from "antd";
import { InboxOutlined } from "@ant-design/icons";
import { useGetDataFilesQuery, useUploadFileMutation } from "../../redux/api";

const columns = [
  {
    name: "File Name",
    dataKey: "File_Name",
  },
  {
    name: "Folder",
    dataKey: "Prefix",
  },
  {
    name: "Size",
    dataKey: "Size",
  },
  {
    name: "Last Modified",
    dataKey: "LastModified",
  },
];

const { Dragger } = Upload;
const { Title, Text } = Typography;

export default function Ontologies() {
  const { data: files } = useGetDataFilesQuery();
  const [sendFile] = useUploadFileMutation();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const onChange = (value) => {
    console.log(`selected ${value}`);
  };
  const onSearch = (value) => {
    console.log("search:", value);
  };
  const showModal = () => {
    setIsModalOpen(true);
  };
  const handleOk = () => {
    setIsModalOpen(false);
  };
  const handleCancel = () => {
    setIsModalOpen(false);
  };

  const props = {
    accept: ".xls, .xlsx, .csv, .rdf, .nq",
    beforeUpload(file) {
      const isXLSX = file.type === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
      if (!isXLSX) {
        message.error(`${file.name} is not a xlsx file`);
      }
      return isXLSX || Upload.LIST_IGNORE;
    },
    customRequest: async (info) => {
      const { file, onSuccess } = info;
      const formData = new FormData()
      formData.append('file', file)

      try {
        await sendFile(formData)
          .unwrap()
          .then((response) => console.log(response));
      } catch {
        notification.error({ message: `file upload failed.` });
      }
    },
  };

  return (
    <>
      <>
        <Row style={{ padding: 16 }}>
          <Col span={20}>
            <Title level={4} style={{ padding: 0, margin: 0 }}>
              Data Files{" "}
            </Title>
          </Col>
          <Col span={4} style={{ justifyContent: "flex-end", alignItems: "flex-end", marginLeft: "auto" }}>
            <Button type="primary" onClick={showModal}>
              Upload File
            </Button>
          </Col>
        </Row>
        <Modal title="File Upload" open={isModalOpen} onOk={handleOk} onCancel={handleCancel}>
          <Row>
            <Col span={24}>
              <Title level={4} style={{ color: "rgb(0, 128, 0)", margin: 0 }}>
                Cargill Enterprise
              </Title>
              <Text italic style={{ fontSize: 12 }}>
                If data is valid for more than one Cargill Enterprise, please upload data file once for each value.
              </Text>
            </Col>
          </Row>
          <Select
            style={{ margin: 8 }}
            showSearch
            placeholder="Select an Enteprise"
            optionFilterProp="label"
            onChange={onChange}
            onSearch={onSearch}
            options={[
              {
                value: "ANH",
                label: "ANH",
              },
              {
                value: "lucy",
                label: "Lucy",
              },
              {
                value: "tom",
                label: "Tom",
              },
            ]}
          />
          <Row>
            <Col span={24}>
              <Title level={4} style={{ color: "rgb(0, 128, 0)", margin: 0 }}>
                Upload Data File
              </Title>
              {/* <ul>
                <li>
                  <Text>xlsx files will be processed in this order:</Text>
                  <ol>
                    <li>
                      <Text>convert to csv</Text>
                    </li>
                    <li>
                      <Text>undergo data validation tests to ensure a successful upload to Neptune</Text>
                    </li>
                    <li>
                      <Text>convert to rdf using the default sparql mapping</Text>
                    </li>
                    <li>
                      <Text>
                        convert to nq by adding the named graph property for the <span style={{ color: "rgb(0, 128, 0)" }}>Cargill Enterprise</span>{" "}
                        value selected in dropdown list
                      </Text>
                    </li>
                  </ol>
                </li>
                <li class="ul_pad">
                  <Text>csv files will be processed using steps 2-4 above</Text>
                </li>
                <li>
                  <Text>rdf files will be processed using step 4 above</Text>
                </li>
                <li>
                  <Text>nq files will be uploaded into Neptune directly</Text>
                </li>
              </ul> */}
            </Col>
          </Row>
          <Dragger {...props} style={{ marginBottom: "12px", height: "100px" }}>
            <p className="ant-upload-drag-icon">
              <InboxOutlined />
            </p>
            <p className="ant-upload-text">Click or drag file to this area to upload</p>
          </Dragger>
          <Text italic style={{ fontSize: 12 }}>
            Valid file types include xlsx, csv, rdf, nq
          </Text>
        </Modal>
      </>
      <CustomTable data={files} columns={columns} />
    </>
  );
}
