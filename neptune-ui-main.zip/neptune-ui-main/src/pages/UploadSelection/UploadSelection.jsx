import React, { useState } from "react";
import { SmileOutlined, SolutionOutlined, UserOutlined } from "@ant-design/icons";
import { Button, Card, Divider, List, Steps, Typography } from "antd";
import ontology from "../../assets/images/map.png";
import mapping from "../../assets/images/file-organizing.png";
import pid from "../../assets/images/technology.png";
import ListType from "../../components/ListType/ListType";
import UploadFiles from "../../components/UploadFiles/UploadFiles";
import { useSelector } from "react-redux";
import Feedback from "../../components/Feedback/Feedback";

export default function UploadSelection() {
  const type = useSelector((state) => state.upload.type);

  const data = [
    {
      type: "upload",
      image: pid,
      title: "Upload PID",
      content: "Profiling integration data files will provide a knowladge base of important buisness processes.",
      button: "Upload PID",
    },
    {
      type: "mapping",
      image: mapping,
      title: "Upload Mapping file",
      content:
        "Mapping files help us associate your data correctly. This is a great option if you have something that needs to be mapped diferently with what we currently have.",
      button: "Upload SPARQL",
    },
    {
      type: "ontology",
      image: ontology,
      title: "Upload Ontology",
      content: "Ontology files help us examine what entities have in common and how they are divided into fundamental classes, known as categories",
      button: "Upload Ontology",
    },
  ];
  return (
    <>
      <Steps
        style={{ padding:20 }}
        items={[
          {
            title: "Select",
            icon: <UserOutlined />,
          },
          {
            title: "Upload File",
            status: type !== "list" ? "finish" : "wait",
            icon: <SolutionOutlined />,
          },
          {
            title: "Result",
            status: type === "result" ? "finish" : "wait",
            icon: <SmileOutlined />,
          },
        ]}
      />
      {
        {
          list: <ListType data={data} />,
          upload: <UploadFiles isHome={true} />,
          result: <Feedback status={"success"} />,
        }[type]
      }
    </>
  );
}
