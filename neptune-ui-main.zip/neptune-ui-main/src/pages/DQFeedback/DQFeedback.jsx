import React from "react";
import { Button, Table, Row, Col, Breadcrumb } from "antd";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import DownloadJson from "../../components/DownloadJson/DownloadJson";

const data = [
  {
    column_name: "",
    error_type: "",
    index_number: -1,
    message: "Notification sent to Neptune bulk loader",
    source_function: "bulk_loader_notification",
    status: "Completed",
  },
  {
    column_name: "",
    error_type: "",
    index_number: -1,
    message: "Deletes rows containing only na, null or empty strings",
    source_function: "delete_empty_rows",
    status: "",
  },
  {
    column_name: "All Columns",
    error_type: "",
    index_number: -1,
    message: "No empty rows to delete",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "",
    error_type: "",
    index_number: -1,
    message: "Strips whitespace around string datatype values",
    source_function: "apply_whitespace_trim",
    status: "",
  },
  {
    column_name: "All Columns",
    error_type: "",
    index_number: -1,
    message: "Whitespace around data values trimmed",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "",
    error_type: "",
    index_number: -1,
    message: "Determines if all expected column headings exist",
    source_function: "check_expected_columns",
    status: "",
  },
  {
    column_name: "All Columns",
    error_type: "",
    index_number: -1,
    message: "All expected columns exist",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "",
    error_type: "",
    index_number: -1,
    message: "Compares column values to lookup value and if similar, replaces                                with the required value",
    source_function: "apply_conform_column_values",
    status: "",
  },
  {
    column_name: "SourcePushOrPull",
    error_type: "",
    index_number: -1,
    message:
      "Row 2: value                                    \u2018PUSHESTO\u2019                                    replaced with                                    \u2018pushesTo\u2019",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "SourcePushOrPull",
    error_type: "",
    index_number: -1,
    message:
      "Row 4: value                                    \u2018push\u2019                                    replaced with                                    \u2018pushesTo\u2019",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "TargetPushOrPull",
    error_type: "",
    index_number: -1,
    message: "No replacements necessary for                                \u2018pushesTo\u2019",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "SourcePushOrPull",
    error_type: "",
    index_number: -1,
    message:
      "Row 7: value                                    \u2018PullsFROM\u2019                                    replaced with                                    \u2018pullsFrom\u2019",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "SourcePushOrPull",
    error_type: "",
    index_number: -1,
    message:
      "Row 9: value                                    \u2018PULL\u2019                                    replaced with                                    \u2018pullsFrom\u2019",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "TargetPushOrPull",
    error_type: "",
    index_number: -1,
    message: "No replacements necessary for                                \u2018pullsFrom\u2019",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "",
    error_type: "",
    index_number: -1,
    message: "Determines if non-nullable columns contain a null value",
    source_function: "check_required_not_null_columns",
    status: "",
  },
  {
    column_name: "SourceSystemEnterprise",
    error_type: "",
    index_number: -1,
    message: "All values exist for non-nullable column",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "SourceSystemBusiness",
    error_type: "",
    index_number: -1,
    message: "All values exist for non-nullable column",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "SourceSystemRegion",
    error_type: "",
    index_number: -1,
    message: "All values exist for non-nullable column",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "SourceDatabaseType",
    error_type: "",
    index_number: -1,
    message: "All values exist for non-nullable column",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "SourceColumn",
    error_type: "",
    index_number: -1,
    message: "All values exist for non-nullable column",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "IntegrationTechnologyID",
    error_type: "",
    index_number: -1,
    message: "All values exist for non-nullable column",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "IntegrationTechnologyTool",
    error_type: "",
    index_number: -1,
    message: "All values exist for non-nullable column",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "SourcePushOrPull",
    error_type: "",
    index_number: -1,
    message: "All values exist for non-nullable column",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "SystemTriggersDataMovementFromSource",
    error_type: "",
    index_number: -1,
    message: "All values exist for non-nullable column",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "TargetPushOrPull",
    error_type: "",
    index_number: -1,
    message: "All values exist for non-nullable column",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "SystemTriggersDataMovementToTarget",
    error_type: "",
    index_number: -1,
    message: "All values exist for non-nullable column",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "TargetSystemEnterprise",
    error_type: "",
    index_number: -1,
    message: "All values exist for non-nullable column",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "TargetSystemBusiness",
    error_type: "",
    index_number: -1,
    message: "All values exist for non-nullable column",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "TargetSystemRegion",
    error_type: "",
    index_number: -1,
    message: "All values exist for non-nullable column",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "TargetDatabaseType",
    error_type: "",
    index_number: -1,
    message: "All values exist for non-nullable column",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "TargetColumn",
    error_type: "",
    index_number: -1,
    message: "All values exist for non-nullable column",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "",
    error_type: "",
    index_number: -1,
    message: "Converts column values to lowercase",
    source_function: "apply_lowercase_columns",
    status: "",
  },
  {
    column_name: "SourceDatabaseType",
    error_type: "",
    index_number: -1,
    message: "Lowercase conversion complete",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "TargetDatabaseType",
    error_type: "",
    index_number: -1,
    message: "Lowercase conversion complete",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "",
    error_type: "",
    index_number: -1,
    message: "Converts column values to uppercase",
    source_function: "apply_uppercase_columns",
    status: "",
  },
  {
    column_name: "SourceSystemEnterprise",
    error_type: "",
    index_number: -1,
    message: "Uppercase conversion complete",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "SourceSystemBusiness",
    error_type: "",
    index_number: -1,
    message: "Uppercase conversion complete",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "SourceSystemRegion",
    error_type: "",
    index_number: -1,
    message: "Uppercase conversion complete",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "TargetSystemEnterprise",
    error_type: "",
    index_number: -1,
    message: "Uppercase conversion complete",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "TargetSystemBusiness",
    error_type: "",
    index_number: -1,
    message: "Uppercase conversion complete",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "TargetSystemRegion",
    error_type: "",
    index_number: -1,
    message: "Uppercase conversion complete",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "",
    error_type: "",
    index_number: -1,
    message: "Determines if column values are in a list of acceptable values",
    source_function: "check_required_column_values",
    status: "",
  },
  {
    column_name: "SourceDatabaseType",
    error_type: "",
    index_number: -1,
    message: "All column values in valid values list: relational, document, graph",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "TargetDatabaseType",
    error_type: "",
    index_number: -1,
    message: "All column values in valid values list: relational, document, graph",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "SourcePushOrPull",
    error_type: "",
    index_number: -1,
    message: "All column values in valid values list: pushesTo, pullsFrom",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "TargetPushOrPull",
    error_type: "",
    index_number: -1,
    message: "All column values in valid values list: pushesTo, pullsFrom",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "",
    error_type: "",
    index_number: -1,
    message: "Determines if a value is required based on the value of another column",
    source_function: "check_required_not_null_with_dependencies",
    status: "",
  },
  {
    column_name: "SourceScheme",
    error_type: "",
    index_number: -1,
    message: "Nulls found, but are valid. SourceDatabaseType values not in: graph, document",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "SourceTable",
    error_type: "",
    index_number: -1,
    message: "No nulls found, so dependency column SourceDatabaseType                                check not required",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "TargetScheme",
    error_type: "",
    index_number: -1,
    message: "Nulls found, but are valid. TargetDatabaseType values not in: graph, document",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "TargetTable",
    error_type: "",
    index_number: -1,
    message: "No nulls found, so dependency column TargetDatabaseType                                check not required",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "",
    error_type: "",
    index_number: -1,
    message: "If column values not in accepted values list, inserts                                replacement value",
    source_function: "apply_lookup_and_replace_column_values",
    status: "",
  },
  {
    column_name: "SourceIsPrimaryKey",
    error_type: "",
    index_number: -1,
    message: "Row 3: Column value                                \u2018F\u2019                                replaced with empty string",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "SourceIsPrimaryKey",
    error_type: "",
    index_number: -1,
    message: "Row 5: Column value                                \u2018nope\u2019                                replaced with empty string",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "SourceIsForeignKey",
    error_type: "",
    index_number: -1,
    message: "Row 4: Column value                                \u2018sure\u2019                                replaced with empty string",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "SourceIsNonKeyDependency",
    error_type: "",
    index_number: -1,
    message: "Row 6: Column value                                \u2018fldkj\u2019                                replaced with empty string",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "SourceIsNonNullable",
    error_type: "",
    index_number: -1,
    message: "No replacements necessary",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "TargetIsPrimaryKey",
    error_type: "",
    index_number: -1,
    message: "No replacements necessary",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "TargetIsForeignKey",
    error_type: "",
    index_number: -1,
    message: "Row 3: Column value                                \u2018F\u2019                                replaced with empty string",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "TargetIsNonKeyDependency",
    error_type: "",
    index_number: -1,
    message: "Row 5: Column value                                \u2018No\u2019                                replaced with empty string",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "TargetIsNonNullable",
    error_type: "",
    index_number: -1,
    message: "No replacements necessary",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "",
    error_type: "",
    index_number: -1,
    message: "Converts column values to specified datatype",
    source_function: "apply_required_datatypes",
    status: "",
  },
  {
    column_name: "DataPayloadVolumeMB",
    error_type: "",
    index_number: -1,
    message: "Datatype conversion to                            \u2018float64\u2019                            complete for non-null values",
    source_function: "",
    status: "Pass",
  },
  {
    column_name: "LatencyMsec",
    error_type: "",
    index_number: -1,
    message: "Datatype conversion to                            \u2018float64\u2019                            complete for non-null values",
    source_function: "",
    status: "Pass",
  },
];

const columns = [
  {
    title: "Source Function",
    dataIndex: "source_function",
    width: "20%",
  },
  {
    title: "Column Name",
    dataIndex: "column_name",
    width: "20%",
  },
  {
    title: "Status",
    dataIndex: "status",
    width: "10%",
  },
  {
    title: "Error Type",
    dataIndex: "error_type",
    width: "10%",
  },
  {
    title: "Description",
    dataIndex: "message",
    width: "40%",
  },
];

export default function DQFeedback() {
  const navigate = useNavigate();
  const filename = useSelector((state) => state.feedback.filename);
  const feedbackdata = useSelector((state) => state.feedback.feedback[filename]);
  return (
    <>
      <Row style={{ padding: 16 }}>
        <Col span={20}>
          <Breadcrumb
            onClick={(item) => {
              console.log(item);
              navigate(item.path);
            }}
            items={[
              {
                title: "Integration Profiling Data",
                href: "/ipd",
              },
              {
                title: "Feedback",
              },
            ]}
          />
        </Col>
        <Col span={4} style={{ justifyContent: "flex-end", alignItems: "flex-end", marginLeft: "auto", width: "100%" }}>
          <DownloadJson />
        </Col>
      </Row>
      <Table
        columns={columns}
        dataSource={feedbackdata}
        pagination={false}
        size="small"
        scroll={{
          x: 1000,
          y: 550,
        }}
      ></Table>
    </>
  );
}
