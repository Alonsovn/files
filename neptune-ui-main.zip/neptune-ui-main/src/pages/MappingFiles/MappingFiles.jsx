import React from 'react'
import CustomTable from "../../components/Table/Table";

const data = [
    {
      key: "1",
      firstName: "profiling.spaqrl",
    },
  ];
  
  const columns = [
    {
      name: "File Name",
      dataKey: "firstName",
    }
  ];

export default function MappingFiles() {
  return (
    <CustomTable data={data} columns={columns} />
  )
}