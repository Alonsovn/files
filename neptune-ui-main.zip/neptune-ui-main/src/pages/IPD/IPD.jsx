import React from "react";
import { Button, Row, Col, Typography } from "antd";
import CustomTable from "../../components/Table/Table";
import { useGetDataFilesQuery } from "../../redux/api";
import { useDispatch } from "react-redux";
import { openModal } from "../../redux/slices/modalSlice";

const columns = [
  {
    name: "File Name",
    dataKey: "File_Name",
  },
  {
    name: "Folder",
    dataKey: "Prefix",
  },
  {
    name: "Size",
    dataKey: "Size",
  },
  {
    name: "Last Modified",
    dataKey: "LastModified",
  },
];

const { Title,  } = Typography;

export default function IPD() {
  const dispatch = useDispatch()
  const { data: files } = useGetDataFilesQuery();

  return (
    <>
      <>
        <Row style={{ padding: 16 }}>
          <Col span={20}>
            <Title level={4} style={{ padding: 0, margin: 0 }}>
              Data Files{" "}
            </Title>
          </Col>
          <Col span={4} style={{ justifyContent: "flex-end", alignItems: "flex-end", marginLeft: "auto" }}>
            <Button type="primary" onClick={()=>dispatch(openModal('upload'))}>
              Upload File
            </Button>
          </Col>
        </Row>
      </>
      <CustomTable data={files} columns={columns} />
    </>
  );
}
