import React from "react";
import { Button, Col, Row, Space, Typography } from "antd";
import Lottie2 from "react-lottie";
import upload from "../../assets/lotties/upload.json";
import { useDispatch } from "react-redux";
import { changeModalSize, openModal } from "../../redux/slices/modalSlice";

const { Title, Text } = Typography;

export default function Home() {
  const dispatch = useDispatch();
  const defaultOptions = {
    loop: true,
    autoplay: true,
    animationData: upload,
    rendererSettings: {
      preserveAspectRatio: "xMidYMid slice",
    },
  };

  return (
    <div>
      <Row>
        <Col span={12}>
          <div style={{ justifyContent: "center", alignContent: "center", height: "100%" }}>
            <Title>Welcome to metadata upload system!</Title>
            <Text>
              This is a comprehensive tool to upload data into metaphactory. The type of data you could upload includes ontologies, profile
              integration data (PID), and mapping files...
            </Text>
            <Space style={{ marginLeft: "auto", padding: 20, width: "100%" }}>
              <Button
                type="primary"
                onClick={() => {
                  dispatch(openModal("upload_selection"));
                  dispatch(changeModalSize("60%"));
                }}
              >
                Get Started
              </Button>
            </Space>
          </div>
        </Col>
        <Col span={12} style={{ justifyContent: "center", alignContent: "center" }}>
          <div>
            <Lottie2 options={defaultOptions} height={500} width={300} />
          </div>
        </Col>
      </Row>
    </div>
  );
}
