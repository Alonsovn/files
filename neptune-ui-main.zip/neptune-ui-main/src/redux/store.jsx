import { configureStore } from "@reduxjs/toolkit";
import { setupListeners } from "@reduxjs/toolkit/query";

import { neptuneServiceApi } from "./api";
import modalSlice from "./slices/modalSlice";
import feedbackSlice from "./slices/feedbackSlice";
import uploadSlice from "./slices/uploadSlice";


export const store = configureStore({
  reducer: {
    // Add the generated reducer as a specific top-level slice
    [neptuneServiceApi.reducerPath]: neptuneServiceApi.reducer,
    modal:modalSlice,
    feedback:feedbackSlice,
    upload:uploadSlice
  },

  // Adding the api middleware enables caching, invalidation, polling,
  // and other useful features of `rtk-query`.
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware().concat(neptuneServiceApi.middleware),
});

// optional, but required for refetchOnFocus/refetchOnReconnect behaviors
// see `setupListeners` docs - takes an optional callback as the 2nd arg for customization
setupListeners(store.dispatch);
