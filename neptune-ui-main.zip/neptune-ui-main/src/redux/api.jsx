// Need to use the React-specific entry point to import createApi
import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

const apiBaseUrl = import.meta.env.VITE_APP_BASE_URL;

// Define a service using a base URL and expected endpoints
export const neptuneServiceApi = createApi({
  reducerPath: "neptuneServiceApi",
  baseQuery: fetchBaseQuery({
    baseUrl: apiBaseUrl,
  }),

  keepUnusedDataFor: 3600,

  tagTypes: ["files"],

  endpoints: (builder) => ({
    // QUERIES
    getDataFiles: builder.query({
      query: () => "files",
      providesTags: ["files"],
    }),
    getDQFeedback: builder.query({
      query: () => "dqfeedback",
      providesTags: ["feedback"],
    }),

    // UPLOAD
    uploadFile: builder.mutation({
      query: (payload) => ({
        url: `/upload?enterprise=${payload.enterprise}`,
        method: "POST",
        body: payload.file,
      }),
      invalidatesTags: ["files"],
    }),
  }),
});

// Export hooks for usage in functional components, which are
// auto-generated based on the defined endpoints
export const { useUploadFileMutation, useGetDataFilesQuery, useGetDQFeedbackQuery } = neptuneServiceApi;
