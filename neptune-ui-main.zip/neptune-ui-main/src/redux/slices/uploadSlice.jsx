import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  type: 'list',
};

export const uploadSlice = createSlice({
  name: "upload",
  initialState,
  reducers: {
    changeUploadType: (state, action) => {
      state.type = action.payload;
    },
  },
});

export const { changeUploadType } = uploadSlice.actions;

export default uploadSlice.reducer;
