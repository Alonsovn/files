import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  open: false,
  type: undefined,
  size: 200,
};

export const modalSlice = createSlice({
  name: "modal",
  initialState,
  reducers: {
    openModal: (state, action) => {
      state.open = true;
      state.type = action.payload;
    },
    closeModal: (state) => {
      state.open = false;
      state.type = undefined;
    },
    changeModalType: (state, action) => {
      state.type = action.payload;
    },
    changeModalSize: (state, action) => {
      state.size = action.payload;
    },
  },
});

export const { openModal, closeModal, changeModalType, changeModalSize } = modalSlice.actions;

export default modalSlice.reducer;
