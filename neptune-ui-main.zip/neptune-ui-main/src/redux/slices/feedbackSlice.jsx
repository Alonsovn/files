import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  feedback: {},
  filename:undefined
};

export const feedbackSlice = createSlice({
  name: "feedback",
  initialState,
  reducers: {
    sendFeedback: (state, action) => {
        state.feedback[action.payload.filename]=action.payload.feedback
    },
    changeFilename: (state, action) => {
        state.filename=action.payload
    },
  },
});

export const { sendFeedback, changeFilename } = feedbackSlice.actions;

export default feedbackSlice.reducer;
