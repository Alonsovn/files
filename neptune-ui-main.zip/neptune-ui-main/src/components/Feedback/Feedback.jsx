import React from "react";
import { Button, Result } from "antd";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { closeModal } from "../../redux/slices/modalSlice";

const Feedback = ({ status }) => {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  return (
    <Result
      status={status}
      title="File has been uploaded succesfully"
      extra={[
        <Button
          type="primary"
          key="console"
          onClick={() => {
            navigate(`/dqfeedback`);
            dispatch(closeModal());
          }}
        >
          View details
        </Button>,
      ]}
    />
  );
};

export default Feedback;
