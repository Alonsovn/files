import React from "react";
import { Modal } from "antd";
import { useDispatch, useSelector } from "react-redux";
import { closeModal } from "../../redux/slices/modalSlice";
import UploadFiles from "../UploadFiles/UploadFiles";
import Feedback from "../Feedback/Feedback";
import UploadSelection from "../../pages/UploadSelection/UploadSelection";
import { changeUploadType } from "../../redux/slices/uploadSlice";

export default function ActionModal() {
  const dispatch = useDispatch();

  const open = useSelector((state) => state.modal.open);
  const size = useSelector((state) => state.modal.size);
  const type = useSelector((state) => state.modal.type);

  const handleOk = () => {
    dispatch(closeModal());
    dispatch(changeUploadType('list'))
  };
  const handleCancel = () => {
    dispatch(closeModal());
    dispatch(changeUploadType('list'))
  };

  return (
    <Modal  open={open} onOk={handleOk} onCancel={handleCancel}  width={size} footer={<></>} >
      {
        {
          upload: <UploadFiles />,
          feedback_success: <Feedback status={"success"}/>,
          feedback_error: <Feedback status={"error"}/>,
          upload_selection: <UploadSelection/>
        }[type]
      }
    </Modal>
  );
}
