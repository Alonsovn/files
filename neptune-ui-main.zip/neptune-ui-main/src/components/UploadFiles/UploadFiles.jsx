import React, { useState } from "react";
import { useUploadFileMutation } from "../../redux/api";
import { Upload, message, notification, Row, Col, Typography, Select } from "antd";
import { InboxOutlined } from "@ant-design/icons";
import { ENTEPRISE, VALID_FILES } from "../../resources/constants";
import { useDispatch } from "react-redux";
import { changeModalType } from "../../redux/slices/modalSlice";
import { changeFilename, sendFeedback } from "../../redux/slices/feedbackSlice";
import { changeUploadType } from "../../redux/slices/uploadSlice";

const { Title, Text } = Typography;
const { Dragger } = Upload;

export default function UploadFiles({isHome}) {
  const dispatch = useDispatch();
  const [enterprise, setEnterprise] = useState("ANH");
  const [sendFile] = useUploadFileMutation();

  const onChange = (value) => {
    setEnterprise(value);
  };

  const props = {
    accept: ".xls, .xlsx, .csv, .rdf, .nq",
    beforeUpload(file) {
      const type = file.name.split(".")[1];
      const isValidType = VALID_FILES.includes(type);
      if (!isValidType) {
        message.error(`${file.name} is not a valid type`);
      }
      return isValidType;
    },
    customRequest: async (info) => {
      const { file, onSuccess } = info;
      const formData = new FormData();
      formData.append("file", file);

      try {
        await sendFile({ file: formData, enterprise: enterprise })
          .unwrap()
          .then((response) => {
            if(isHome){
              if (response.status === "Success") {
                dispatch(changeUploadType("result"));
              } else {
                dispatch(changeUploadType("result"));
              }
              dispatch(changeFilename(response.filename));
              dispatch(sendFeedback({ filename: response.filename, feedback: response.feedback }));
            } else {
              if (response.status === "Success") {
                dispatch(changeModalType("feedback_success"));
              } else {
                dispatch(changeModalType("feedback_error"));
              }
              dispatch(changeFilename(response.filename));
              dispatch(sendFeedback({ filename: response.filename, feedback: response.feedback }));
            }
          });
      } catch {
        notification.error({ message: `file upload failed.` });
      }
    },
  };

  return (
    <>
      <Row>
        <Col span={24}>
          <Title level={4} style={{ color: "#007582", margin: 0 }}>
            Cargill Enterprise
          </Title>
          <Text italic style={{ fontSize: 12 }} type="secondary">
            If data is valid for more than one Cargill Enterprise, please upload data file once for each value.
          </Text>
        </Col>
      </Row>
      <Select style={{ margin: 8, width: 200 }} placeholder="Select an Enteprise" defaultValue={enterprise} onChange={onChange} options={ENTEPRISE} />
      <Row>
        <Col span={24}>
          <Title level={4} style={{ color: "#007582", margin: 0 }}>
            Upload Data File
          </Title>
        </Col>
      </Row>
      <Dragger {...props} style={{ marginBottom: "12px", height: "100px" }}>
        <p className="ant-upload-drag-icon">
          <InboxOutlined />
        </p>
        <p className="ant-upload-text">Click or drag file to this area to upload</p>
      </Dragger>
      <Text italic style={{ fontSize: 12 }} type="secondary">
        Valid file types include xlsx, csv, rdf, nq
      </Text>
    </>
  );
}
