import { Button } from "antd";
import React from "react";
import * as FileSaver from "file-saver";
import * as XLSX from "xlsx";
import { useSelector } from "react-redux";

const removeKeyFromObjects = (arr) => {
    const keyOrder = ['source_function', 'column_name', 'status','error_type', "message"]
 return arr.map((obj) => {
    const arrangedObject = {};
    keyOrder.forEach((key) => {
      if (obj.hasOwnProperty(key)) {
        arrangedObject[key] = obj[key];
      }
    });
    return arrangedObject;
  });
};

export default function DownloadJson() {
  const fileName = useSelector((state) => state.feedback.filename);
  const data = useSelector((state) => state.feedback.feedback[fileName]);

  const fileType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8";
  const fileExtension = ".xlsx";

  const exportToCSV = (csvData, fileName) => {
    if (csvData){
        const cleanData = removeKeyFromObjects(csvData);
        const ws = XLSX.utils.json_to_sheet(cleanData);
        const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
        const excelBuffer = XLSX.write(wb, { bookType: "xlsx", type: "array" });
        const data = new Blob([excelBuffer], { type: fileType });
        FileSaver.saveAs(data, fileName + fileExtension);
    }
  };

  return (
    <Button type="primary" onClick={(e) => exportToCSV(data, fileName)}>
      Download CSV
    </Button>
  );
}
