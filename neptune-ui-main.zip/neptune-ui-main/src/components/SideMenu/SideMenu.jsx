import React from "react";
import { Layout, Menu, Col, Row } from "antd";
import { TAB } from "../../resources/constants";
import logo from "../../assets/images/Cargill.svg";
import { useNavigate } from "react-router-dom";

const { Sider } = Layout;

export default function SideMenu() {
  const navigate = useNavigate();
  return (
    <Sider>
      <Row>
        <Col span={16}>
          <img src={logo} alt="logo" loading="lazy" style={{ width: 133, height: 64, paddingInline: 16 }} />
        </Col>
        <Col span={8}>
        </Col>
      </Row>
      <Menu theme="dark" mode="inline" defaultSelectedKeys={["/home"]} items={TAB} onSelect={(item) => navigate(item.key)} />
    </Sider>
  );
}
