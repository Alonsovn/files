import React from "react";
import { Button, Card, Divider, List,Typography } from "antd";
import { useDispatch } from "react-redux";
import { changeUploadType } from "../../redux/slices/uploadSlice";
const { Title, Text } = Typography;
export default function ListType({data}) {
  const dispatch = useDispatch()
  
  return (
    <List
      grid={{ gutter: 16, column: 3 }}
      dataSource={data}
      renderItem={(item) => (
        <List.Item>
          <Card>
            <div style={{ height: 350, display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
              <div style={{ justifyContent: "center", alignContent: "center", width: "100%", display: "flex" }}>
                <img src={item.image} style={{ width: 80, height: 80 }} alt={item.title} />
              </div>
              <Divider style={{ marginBottom: 8 }} />
              <Title level={5} style={{ marginTop: 0 }}>
                {" "}
                {item.title}
              </Title>
              <Text type="secondary" style={{ display: "block" }}>
                {item.content}
              </Text>
              <div style={{ marginTop: "auto", alignContent: "flex-end" }}>
                <Button type="primary" onClick={()=>dispatch(changeUploadType(item.type))}>
                  {item.button}
                </Button>
              </div>
            </div>
          </Card>
        </List.Item>
      )}
    />
  );
}
