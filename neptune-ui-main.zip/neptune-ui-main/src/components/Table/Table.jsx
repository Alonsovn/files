import React from "react";
import { Button, Space, Table, Typography } from "antd";
import { DownloadOutlined, EyeOutlined } from "@ant-design/icons";
import axios from "axios";

const { Column } = Table;
const { Text } = Typography;

export default function CustomTable({ columns, data }) {
  const getObjectUrl = (props) => {
    return window.URL.createObjectURL(new Blob([props], { type: props.type }));
  };

  const handleDownload = async (item) => {
    await axios({
      method: "GET",
      url: `${import.meta.env.VITE_APP_BASE_URL}/download?filename=${item.File_Name}&prefix=${item.Prefix}`,
      responseType: "blob",
    })
      .then((res) => {
        const link = document.createElement("a");
        link.href = getObjectUrl(res.data);
        link.setAttribute("download", item.File_Name);
        document.body.appendChild(link);
        link.click();
        link.remove();
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <Table dataSource={data} style={{maxHeight:"70%"}} size='small'>
      {columns.map((item, index) => {
        if (item.name === "Size") {
          return (
            <Column
              title={item.name}
              dataIndex={item.dataKey}
              key={index}
              render={(_, record) => {
                const megabytes = record.Size / (1024 * 1024);
                return <Text key={index}>{megabytes.toFixed(2)} MB</Text>;
              }}
            />
          );
        } else {
          return <Column title={item.name} dataIndex={item.dataKey} key={index} />;
        }
      })}
      <Column
        title="Action"
        key="action"
        render={(text, record, index) => (
          <Space size="middle">
            <Button key={record.File_Name} shape="circle" icon={<DownloadOutlined />} onClick={() => handleDownload(record)} />
          </Space>
        )}
      />
    </Table>
  );
}
