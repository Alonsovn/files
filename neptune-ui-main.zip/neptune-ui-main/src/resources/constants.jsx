import { HomeOutlined, UserOutlined, VideoCameraOutlined, FileAddOutlined } from "@ant-design/icons";

export const TAB = [
  {
    key: "/home",
    icon: <HomeOutlined />,
    label: "Home",
    path: "/home",
  },
  {
    key: "/ipd",
    icon: <FileAddOutlined />,
    label: "IPD",
    path: "/ipd",
  },
  {
    key: "/ontologies",
    icon: <UserOutlined />,
    label: "Ontologies",
    path: "/ontologies",
  },
  {
    key: "/mappingfiles",
    icon: <VideoCameraOutlined />,
    label: "Mapping files",
    path: "/mappingfiles",
  },
];

export const ENTEPRISE = [
  {
    value: "ANH",
    label: "ANH",
  },
  {
    value: "CASC",
    label: "CASC",
  },
  {
    value: "CFB",
    label: "CFB",
  },
  {
    value: "CPS",
    label: "CPS",
  },
  {
    value: "FSM",
    label: "FSM",
  },
  {
    value: "TRM",
    label: "TRM",
  },
];

export const VALID_FILES=[
  'nq',
  "xlsx",
  'csv',
  'rdf'
]