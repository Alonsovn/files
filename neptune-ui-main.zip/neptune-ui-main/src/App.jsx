import React, { useEffect, useState } from "react";
import { Navigate, Route, Routes, useNavigate } from "react-router-dom";
import { Layout, theme, Typography } from "antd";
import { InteractionRequiredAuthError, InteractionStatus, InteractionType } from "@azure/msal-browser";
import SideMenu from "./components/SideMenu/SideMenu";
import { MsalAuthenticationTemplate, useMsal } from "@azure/msal-react";
import { CustomNavigationClient } from "./services/sso/NavigationClient";
import { callMsGraph } from "./services/sso/MsGraphApiCall";
import { loginRequest } from "./services/sso/authConfig";
import MappingFiles from "./pages/MappingFiles/MappingFiles";
import Home from "./pages/Home/Home";
import IPD from "./pages/IPD/IPD";
import ActionModal from "./components/ActionModal/ActionModal";
import DQFeedback from "./pages/DQFeedback/DQFeedback";

const { Content } = Layout;
const { Text } = Typography;

const App = () => {
  const { instance, inProgress } = useMsal();
  const navigate = useNavigate();
  const [graphData, setGraphData] = useState(null);
  const {
    token: { colorBgContainer, borderRadiusLG },
  } = theme.useToken();
  const navigationClient = new CustomNavigationClient(navigate);
  instance.setNavigationClient(navigationClient);

  useEffect(() => {
    if (!graphData && inProgress === InteractionStatus.None) {
      callMsGraph()
        .then((response) => setGraphData(response))
        .catch((e) => {
          if (e instanceof InteractionRequiredAuthError) {
            instance.acquireTokenRedirect({
              ...loginRequest,
              account: instance.getActiveAccount(),
            });
          }
        });
    }
  }, [inProgress, graphData, instance]);

  const authRequest = {
    ...loginRequest,
  };

  return (
    <React.Fragment>
      <MsalAuthenticationTemplate
        interactionType={InteractionType.Redirect}
        authenticationRequest={authRequest}
        errorComponent={ErrorComponent}
        loadingComponent={Loading}
      >
        <Layout style={{ height: "100vh", width: "100%" }}>
          <SideMenu />
          <Layout>
            <Content
              style={{
                margin: "24px 16px",
                padding: 24,
                minHeight: 280,
                background: colorBgContainer,
                borderRadius: borderRadiusLG,
              }}
            >
              <Routes>
                <Route index element={<Navigate to={"/home"} />} />
                <Route path={"/home"} element={<Home />} />
                <Route path={"/ipd"} element={<IPD />} />
                <Route path={"/dqfeedback"} element={<DQFeedback />} />
                <Route path={"/mappingfiles"} element={<MappingFiles />} />
              </Routes>
            </Content>
          </Layout>
        </Layout>
        <ActionModal />
      </MsalAuthenticationTemplate>
    </React.Fragment>
  );
};
export default App;

export const ErrorComponent = ({ error }) => {
  return <Text>An Error Occurred: {error.errorCode}</Text>;
};

export const Loading = () => {
  return <Text variant="h6">Authentication in progress...</Text>;
};
